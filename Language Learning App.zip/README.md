
  # Language Learning App

  This is a code bundle for Language Learning App. The original project is available at https://www.figma.com/design/BNVq3Gjy2WdAGfPIRLtZsd/Language-Learning-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  